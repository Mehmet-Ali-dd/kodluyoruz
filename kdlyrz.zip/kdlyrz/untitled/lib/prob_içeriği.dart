import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // inputFormatters için gerekli

class ProbIcerigiSayfasi extends StatefulWidget {
  final String problemName;

  ProbIcerigiSayfasi({required this.problemName});

  @override
  _ProbIcerigiSayfasiState createState() => _ProbIcerigiSayfasiState();
}

class _ProbIcerigiSayfasiState extends State<ProbIcerigiSayfasi> {
  final TextEditingController _sikayetController = TextEditingController();
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  bool _isFormVisible = false; // Form görünürlüğü
  bool _isDescriptionVisible = false; // Açıklama görünürlüğü

  // Uyarı mesajını göstermek için kullanılan fonksiyon
  void _showAlertDialog(String message) {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Center(child: Text("Uyarı", style: TextStyle(color: Colors.red),)),

          content: Text(
            message,
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 20),
          ),
          backgroundColor: Colors.blue.shade50, // Dialog arka plan rengi
          actions: <Widget>[
            Center(
              child: TextButton(
                child: Text("Tamam", style:TextStyle(fontSize: 20, color: Colors.black)),
                onPressed: () {
                  Navigator.of(context).pop(); // Dialog'u kapatır
                },
              ),
            ),
          ],
        );
      },
    );
  }

  void _submit() {
    // Eğer e-posta kısmı boş değilse ve "@gmail.com" eklenmemişse, ekleyelim
    if (_emailController.text.isNotEmpty &&
        !_emailController.text.endsWith("@gmail.com")) {
      _emailController.text = _emailController.text + "@gmail.com";
    }

    // Boş alan kontrolü
    if (_nameController.text.isNotEmpty &&
        _emailController.text.isNotEmpty &&
        _phoneController.text.isNotEmpty) {
      _showAlertDialog("Mesajınız gönderildi");
    } else {
      // Eksik bilgi uyarısı
      _showAlertDialog("Eksik bilgi");
    }
  }

  // Problem adına göre farklı metinler oluşturuyoruz
  String _getProblemText() {
    if (widget.problemName == "İzinsiz Fotoğraf Paylaşımı") {
      return "Eğer size ait bir fotoğrafın izinsiz şekilde paylaşıldığını fark ettiyseniz, Türk Ceza Kanunu’nun (TCK) 134. maddesi (özel hayatın gizliliğini ihlal) ve Kişisel Verilerin Korunması Kanunu (KVKK) çerçevesinde yasal haklarınızı kullanabilirsiniz. Bu tür bir ihlalle karşılaştığınızda, aşağıdaki formu doldurarak hukuki işlem başlatabilirsiniz.";
    } else if (widget.problemName == "Kişisel Bilgi Paylaşımı") {
      return "Eğer size ait kişisel bilgilerin izinsiz şekilde paylaşıldığını fark ettiyseniz, Türk Ceza Kanunu’nun (TCK) 136. maddesi (kişisel verilerin hukuka aykırı olarak ele geçirilmesi ve yayılması) ve Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında yasal haklarınızı kullanabilirsiniz. Böyle bir durumla karşılaştığınızda, aşağıdaki formu doldurarak hukuki işlem başlatabilirsiniz.";
    } else if (widget.problemName == "Tehdit") {
      return "Bir kişiye zarar vereceğini söyleyerek korkutma eylemidir. Türk Ceza Kanunu'nun 106. maddesi uyarınca, tehdit suçu 6 aydan 2 yıla kadar hapisle cezalandırılır.Böyle bir şikayetiniz varsa aşağıdaki formu doldurunuz.";
    } else if (widget.problemName == "Trolleme") {
      return "Dijital platformlarda kişilere rahatsızlık verme ve yanıltıcı bilgi yayma eylemleridir. Türk Ceza Kanunu’nun 125. maddesi (hakaret), 106. maddesi (tehdit) ve 216. maddesi (halkı kin ve düşmanlığa tahrik) kapsamında suç teşkil edebilir. Ayrıca Kişisel Verilerin Korunması Kanunu (KVKK) ile de ilgili olabilir. Böyle bir şikayetiniz varsa aşağıdaki formu doldurunuz.";
    } else if (widget.problemName == "Oyun İçi Zorbalama") {
      return "Girdiğiniz bir oyunda hakaret, tehdit, taciz veya dışlama gibi saldırgan davranışlara maruz kalıyorsanız, Türk Ceza Kanunu’nun (TCK) 125. maddesi (hakaret), 106. maddesi (tehdit) ve Kişisel Verilerin Korunması Kanunu (KVKK) kapsamında yasal yollara başvurabilirsiniz. Böyle bir şikayetiniz varsa aşağıdaki formu doldurunuz.";
    } else {
      return ""; // Eğer farklı bir problem adı varsa boş bırak
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.blue.shade100,
      appBar: AppBar(
        title: Text(widget.problemName),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            // Problem adına göre metni dinamik olarak ekliyoruz
            Text(
              _getProblemText(), // Dinamik metin
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20), // Metin ile form arasına boşluk ekle

            // Formu göster/gizle butonu
            ElevatedButton(
              onPressed: () {
                setState(() {
                  _isFormVisible =
                      !_isFormVisible; // Form görünürlüğünü değiştir
                });
              },
              child: Text(_isFormVisible ? "Formu Gizle" : "Formu Göster", style: TextStyle(color: Colors.black),),
            ),
            if (_isFormVisible) ...[
              // Şikayet giriş alanı
              TextField(
                controller: _sikayetController,
                decoration: InputDecoration(labelText: "Şikayetiniz"),
              ),
              SizedBox(height: 40),
              // Ad giriş alanı
              TextField(
                controller: _nameController,
                decoration: InputDecoration(labelText: "Adınız"),
              ),
              SizedBox(height: 40),
              // E-posta giriş alanı
              TextField(
                controller: _emailController,
                decoration: InputDecoration(labelText: "E-posta"),
              ),
              SizedBox(height: 40),
              // Telefon numarası giriş alanı (Sadece 11 hanelik sayı)
              TextField(
                controller: _phoneController,
                decoration: InputDecoration(labelText: "Telefon Numarası"),
                keyboardType: TextInputType.number,
                inputFormatters: [
                  FilteringTextInputFormatter
                      .digitsOnly, // Sadece sayılara izin verir
                  LengthLimitingTextInputFormatter(11), // Maksimum 11 karakter
                ],
              ),

              SizedBox(height: 40),
              // Butonu ortalıyoruz
              Center(
                child: ElevatedButton(
                  onPressed: _submit,
                  child: Text("Gönder",style: TextStyle(color: Colors.black),),
                ),
              ),
            ],
            SizedBox(height: 20),

            // Açıklamayı göster/gizle butonu

            if (_isDescriptionVisible)
              Padding(
                padding: const EdgeInsets.only(top: 8.0),
                child: Text(_getProblemText()), // Problemin açıklaması
              ),
          ],
        ),
      ),
    );
  }
}
