import 'package:flutter/material.dart';

import 'prob_içeriği.dart';

class ProblemlerSayfasi extends StatelessWidget {
  final List<String> problemler = [
    "İzinsiz Fotoğraf Paylaşımı",
    "Kişisel Bilgi Paylaşımı",
    "Tehdit",
    "Trolleme",
    "Oyun İçi Zorbalama",
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.brown.shade50,
      appBar: AppBar(
        title: Text("Problemler"),
        backgroundColor: Colors.blue.shade400,
      ),
      body: Container(
        decoration: BoxDecoration(
         image: DecorationImage(
          image: AssetImage("assets/home.jpg"),
          fit: BoxFit.cover,
         ),
       ),
       child: ListView.builder(
        itemCount: problemler.length,
        itemBuilder: (context, index) {
          return GestureDetector(
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) =>
                      ProbIcerigiSayfasi(problemName: problemler[index]),
                ),
              );
            },
            child: Container(
              margin: EdgeInsets.symmetric(
                  horizontal: 16, vertical: 8), // Kenar boşlukları
              padding: EdgeInsets.all(16), // İçerik boşlukları
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12), // Köşeleri yuvarlama
              ),
              child: Text(
                problemler[index],
                style: TextStyle(
                    fontSize: 18, color: Colors.black), // Yazı rengi ve boyutu
              ),
            ),
          );
        },
      ),
      ),
    );
  }
}
