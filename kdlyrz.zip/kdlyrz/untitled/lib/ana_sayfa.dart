import 'package:flutter/material.dart';

import 'problemler.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Yardım Çağrı Uygulaması',
      home: AnaSayfa(),
    );
  }
}

class AnaSayfa extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
         image: DecorationImage(
          image: AssetImage("assets/home.jpg"),
          fit: BoxFit.cover,
         ),
       ),
       child: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: <Widget>[
            Text("Yardım Çağrı", style: TextStyle(fontSize: 35, color: Colors.white)),
            Text("Uygulaması", style: TextStyle(fontSize: 35, color: Colors.white)),
            SizedBox(height: 150),
            ElevatedButton(
              child: Text(
                "Yardım Al",
                style: TextStyle(fontSize: 25, color: Colors.black),
              ),
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => ProblemlerSayfasi()),
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.blue.shade400,
                shape: CircleBorder(),
                padding: EdgeInsets.all(
                    20), // Butonun boyutunu ayarlamak için padding
                minimumSize: Size(150, 150),
                elevation: 15,
                shadowColor: Colors.black.withOpacity(0.9),
              ),
            ),
          ],
        ),
      ),
      ),
    );
  }
}
