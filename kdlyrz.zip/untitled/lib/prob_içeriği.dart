import 'package:flutter/material.dart';

class ProbIcerigiSayfasi extends StatefulWidget {
  final String problemName;

  ProbIcerigiSayfasi({required this.problemName});

  @override
  _ProbIcerigiSayfasiState createState() => _ProbIcerigiSayfasiState();
}

class _ProbIcerigiSayfasiState extends State<ProbIcerigiSayfasi> {
  final TextEditingController _nameController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _phoneController = TextEditingController();

  void _submit() {
    if (_nameController.text.isNotEmpty &&
        _emailController.text.isNotEmpty &&
        _phoneController.text.isNotEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Mesajınız gönderildi")));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Eksik bilgi")));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.problemName)),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: <Widget>[
            TextField(
              controller: _nameController,
              decoration: InputDecoration(labelText: "Adınız"),
            ),
            SizedBox(height: 50), // 50 birim boşluk
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "E-posta"),
            ),
            SizedBox(height: 50), // 50 birim boşluk
            TextField(
              controller: _phoneController,
              decoration: InputDecoration(labelText: "Telefon Numarası"),
            ),
            SizedBox(height: 50), // 50 birim boşluk
            ElevatedButton(
              onPressed: _submit,
              child: Text("Gönder"),
            ),
          ],
        ),
      ),
    );
  }
}
